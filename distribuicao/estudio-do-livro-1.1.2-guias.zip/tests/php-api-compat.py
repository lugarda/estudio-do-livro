"""Exercise the unchanged PHP API in a disposable localhost fixture, not HostGator."""
from pathlib import Path
import os,json,tempfile,subprocess,urllib.request,urllib.error,http.cookiejar,time,shutil
ROOT=Path(__file__).resolve().parents[1]
PHP=os.environ['PHP_BIN'];BOOKS=Path(os.environ['EXISTING_BOOKS']);results=[]
with tempfile.TemporaryDirectory(prefix='estudio-cpanel-api-') as tmp:
 base=Path(tmp);pub=base/'public';data=base/'data';pub.mkdir();data.mkdir(mode=0o700);(data/'books').mkdir(mode=0o700)
 shutil.copyfile(ROOT/'public/api.php',pub/'api.php')
 shutil.copyfile(ROOT/'public/auth-recovery.php',pub/'auth-recovery.php')
 (data/'install.key').write_text('CHAVE-SOMENTE-TESTE-LOCAL-2026')
 originals=[]
 for f in sorted(BOOKS.glob('*.json')):
  b=json.loads(f.read_text());originals.append(b);(data/'books'/(b['id']+'.json')).write_text(json.dumps(b,ensure_ascii=False))
 (base/'sessions').mkdir(mode=0o700)
 log=open(base/'server.log','wb')
 server=subprocess.Popen([PHP,'-n','-d','session.save_path='+str(base/'sessions'),'-S','127.0.0.1:4188','-t',str(pub)],stdout=log,stderr=log)
 jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar));csrf=''
 def request(action,payload=None,query='',bad_csrf=False):
  headers={};body=None
  if payload is not None:body=json.dumps(payload,ensure_ascii=False).encode();headers={'Content-Type':'application/json','X-CSRF-Token':'invalid' if bad_csrf else csrf}
  req=urllib.request.Request('http://127.0.0.1:4188/api.php?action='+action+query,data=body,headers=headers)
  try:
   with opener.open(req,timeout=15) as r:return r.status,json.load(r)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 try:
  for _ in range(40):
   try:status,info=request('status');break
   except urllib.error.URLError:time.sleep(.05)
  else:raise RuntimeError('PHP fixture did not start')
  csrf=info['csrf'];assert request('books')[0]==401
  status,info=request('setup',{'key':'CHAVE-SOMENTE-TESTE-LOCAL-2026','password':'Senha-local-nunca-producao-2026'});assert status==200,info;csrf=info['csrf']
  results.append({'case':'synthetic_login_csrf_and_private_storage','passed':True})
  assert len(request('books')[1]['books'])==len(originals)
  for index,original in enumerate(originals):
   status,info=request('book',query='&id='+original['id']);assert status==200
   b=info['book'];b.pop('publication',None);assert b==original
   before=(data/'books'/(b['id']+'.json')).read_bytes()
   assert request('save',{'book':b,'expectedRevision':b.get('revision',0)},bad_csrf=True)[0]==403
   assert (data/'books'/(b['id']+'.json')).read_bytes()==before
   status,saved=request('save',{'book':b,'expectedRevision':b.get('revision',0)});assert status==200,saved
   stored=json.loads((data/'books'/(b['id']+'.json')).read_text())
   expected={**original,'revision':original.get('revision',0)+1,'updatedAt':stored['updatedAt']};assert stored==expected
   assert request('save',{'book':b,'expectedRevision':b.get('revision',0)})[0]==409
   assert json.loads((data/'books'/(b['id']+'.json')).read_text())==stored
   status,published=request('publish',{'id':b['id']});assert status==200
   token=published['token'];status,snapshot=request('read',query='&token='+token);assert status==200
   for key in ['chapters','pages','pageAssets']:assert snapshot['book'][key]==original.get(key,[])
   status,again=request('publish',{'id':b['id']});assert status==200 and again['token']==token
   assert request('unpublish',{'id':b['id']})[0]==200
   assert request('read',query='&token='+token)[0]==404
   assert json.loads((data/'books'/(b['id']+'.json')).read_text())==stored
   results.append({'case':'existing_project_'+str(index+1)+'_read_save_conflict_publish_unpublish','passed':True})
  profile={'id':'perfil-local-1234','name':'Perfil sintético','layout':originals[0]['layout'],'print':originals[0]['print']}
  assert request('saveProfile',{'profile':profile})[0]==200
  assert profile in request('profiles')[1]['profiles']
  results.append({'case':'profile_roundtrip','passed':True})
 finally:
  server.terminate();server.wait(timeout=10);log.close()
(ROOT/'reports').mkdir(exist_ok=True)
(ROOT/'reports/php-api-compat.json').write_text(json.dumps({'scope':'disposable local PHP fixture; synthetic account only','real_hosting_changed':False,'real_credentials_used':False,'passed':results},indent=2)+'\n')
print(str(len(results))+' PHP API compatibility scenarios passed; no remote changes')
