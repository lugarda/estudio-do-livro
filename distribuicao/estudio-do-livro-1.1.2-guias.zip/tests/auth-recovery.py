"""Disposable PHP fixture, synthetic account, local mail sink; never calls hosting."""
import os,json,subprocess,tempfile,shutil,time,urllib.request,urllib.error,http.cookiejar,re,hashlib,concurrent.futures
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PHP=os.environ['PHP_BIN'];results=[]
with tempfile.TemporaryDirectory(prefix='estudio-auth-') as td:
 base=Path(td);pub=base/'public';data=base/'data';pub.mkdir();data.mkdir(mode=0o700);(base/'sessions').mkdir()
 for n in ['books','profiles','publication','published','rate']:(data/n).mkdir()
 shutil.copytree(ROOT/'public',pub,dirs_exist_ok=True)
 mail=base/'mail.txt';sink=base/'sendmail.py';sink.write_text('#!/usr/bin/python3\nimport sys\nfrom pathlib import Path\nPath('+repr(str(mail))+').write_bytes(sys.stdin.buffer.read())\n');sink.chmod(0o700)
 (data/'install.key').write_text('synthetic-install-key-0123456789')
 for n in ['books','profiles','publication','published']:(data/n/'preserve.json').write_text('{"synthetic":"unchanged-'+n+'"}')
 preserve={str(f):f.read_bytes() for n in ['books','profiles','publication','published'] for f in (data/n).iterdir()}
 env=dict(os.environ,PHP_CLI_SERVER_WORKERS='4');log=open(base/'server.log','wb')
 # Dedicated process group allows terminating every local worker.
 server=subprocess.Popen([PHP,'-n','-d','session.save_path='+str(base/'sessions'),'-d','sendmail_path='+str(sink),'-S','127.0.0.1:4192','-t',str(pub)],env=env,stdout=log,stderr=log,start_new_session=True)
 class Client:
  def __init__(self):self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));self.csrf=''
  def req(self,a,d=None,csrf=None):
   headers={};payload=None
   if d is not None:payload=json.dumps(d).encode();headers={'Content-Type':'application/json','X-CSRF-Token':self.csrf if csrf is None else csrf}
   req=urllib.request.Request('http://127.0.0.1:4192/api.php?action='+a,data=payload,headers=headers)
   try:
    with self.opener.open(req,timeout=20) as r:return r.status,json.load(r)
   except urllib.error.HTTPError as e:return e.code,json.load(e)
  def status(self):code,r=self.req('status');assert code==200;self.csrf=r['csrf'];return r
  def login(self,p):
   self.status();code,r=self.req('login',{'password':p})
   if code==200:self.csrf=r['csrf']
   return code,r
 def check(name):results.append({'case':name,'passed':True});print(name,flush=True)
 def account():return json.loads((data/'account.json').read_text())
 def change(a):(data/'account.json').write_text(json.dumps(a))
 def token(kind):return re.search(r'#recovery='+kind+r'\.([a-f0-9]{64})',mail.read_text())[1]
 try:
  c=Client()
  for _ in range(70):
   try:c.status();break
   except urllib.error.URLError:time.sleep(.05)
  p='Synthetic-password-2026';new='New-synthetic-password-2026'
  code,r=c.req('setup',{'key':'synthetic-install-key-0123456789','password':p});assert code==200,r;c.csrf=r['csrf'];assert c.status()['logged'];assert c.req('books')[0]==200
  check('legacy_setup_and_login_work_before_reset')
  a=account();a['customFutureField']={'retain':True};change(a)
  assert c.req('beginEmail',{'password':p,'email':'owner@example.test'})[0]==503 and not mail.exists()
  check('mail_disabled_without_private_configuration')
  config={'enabled':True,'baseUrl':'https://estudiodolivro.eduardogoncalvespsico.com','from':'no-reply@example.test'};(data/'recovery-config.json').write_text(json.dumps(config))
  assert c.req('beginEmail',{'password':'wrong','email':'owner@example.test'})[0]==403
  assert c.req('beginEmail',{'password':p,'email':'bad\r\nBcc: attacker@example.test'})[0]==400
  assert c.req('beginEmail',{'password':p,'email':'owner@example.test'},csrf='bad')[0]==403
  assert c.req('beginEmail',{'password':p,'email':'owner@example.test'})[0]==200
  raw=token('verify');assert raw not in (data/'account.json').read_text();assert not account().get('recoveryEmailVerifiedAt')
  check('email_requires_session_current_password_csrf_and_verification_hash_only')
  assert c.req('verifyEmail',{'token':raw})[0]==200
  assert c.req('verifyEmail',{'token':raw})[0]==400
  check('email_verification_single_use')
  anon=Client();anon.status();assert anon.req('books')[0]==401
  response=anon.req('requestRecovery',{'email':'missing@example.test'})
  valid=anon.req('requestRecovery',{'email':'owner@example.test'});assert valid==response
  raw=token('reset');assert raw not in (data/'account.json').read_text()
  for _ in range(6):assert anon.req('requestRecovery',{'email':'missing@example.test'})==response
  check('recovery_no_account_enumeration_and_throttled_response_identical')
  assert anon.req('resetPassword',{'token':raw,'password':new,'confirm':'different'})[0]==400
  assert anon.req('resetPassword',{'token':raw,'password':'é'*37,'confirm':'é'*37})[0]==400
  assert anon.req('resetPassword',{'token':'f'*64,'password':new,'confirm':new})[0]==400
  a=account();saved=a['recovery']['reset']['expires'];a['recovery']['reset']['expires']=time.time()-1;change(a)
  assert anon.req('resetPassword',{'token':raw,'password':new,'confirm':new})[0]==400
  a['recovery']['reset']['expires']=saved;change(a)
  check('wrong_expired_mismatched_and_overlength_passwords_rejected')
  assert anon.req('resetPassword',{'token':raw,'password':new,'confirm':new})[0]==200
  anon.status();assert anon.req('resetPassword',{'token':raw,'password':p,'confirm':p})[0]==400
  assert not c.status()['logged'];assert c.req('books')[0]==401
  assert c.login(p)[0]==401;assert c.login(new)[0]==200
  assert account()['customFutureField']=={'retain':True};assert account()['recoveryEmail']=='owner@example.test'
  check('password_reset_invalidates_tokens_old_password_all_sessions_preserves_account')
  # An admin key is created only in the local private fixture to simulate cPanel control.
  key='a1'*32;(data/'admin-recovery.key').write_text(key)
  admin=Client();admin.status();assert admin.req('adminRecovery',{'key':'b2'*32,'password':p,'confirm':p})[0]==403
  os.utime(data/'admin-recovery.key',(time.time()-1801,)*2)
  assert admin.req('adminRecovery',{'key':key,'password':p,'confirm':p})[0]==403
  os.utime(data/'admin-recovery.key',None)
  assert admin.req('adminRecovery',{'key':key,'password':p,'confirm':p})[0]==200
  (data/'admin-recovery.key').write_text(key)
  admin.status();assert admin.req('adminRecovery',{'key':key,'password':p,'confirm':p})[0]==403
  assert not c.status()['logged'];assert c.login(p)[0]==200
  check('administrative_proof_expiration_replay_and_session_revocation')
  # Clear synthetic rate fixtures only; no real data is used.
  for f in (data/'rate').glob('*.json'):f.unlink()
  assert admin.req('requestRecovery',{'email':'owner@example.test'})[0]==200
  raw=token('reset');clients=[Client(),Client()]
  for client in clients:client.status()
  with concurrent.futures.ThreadPoolExecutor(2) as pool:
   outcomes=list(pool.map(lambda client:client.req('resetPassword',{'token':raw,'password':new,'confirm':new})[0],clients))
  assert sorted(outcomes)==[200,400],outcomes
  check('two_php_workers_two_sessions_concurrent_token_only_one_success')
  assert c.login(new)[0]==200
  for f in (data/'rate').glob('*.json'):f.unlink()
  for _ in range(8):assert admin.req('login',{'password':'wrong'})[0]==401
  assert admin.req('login',{'password':new})[0]==429
  check('legacy_login_lockout_reproduced_even_when_password_correct')
  assert all(Path(f).read_bytes()==body for f,body in preserve.items())
  check('books_profiles_publications_unchanged_byte_for_byte')
  # A token is invalidated if another authenticated password change occurred.
  assert account()['password'] and 'recovery' not in account()
  check('tokens_consumed_atomically_in_account_write')
  # Configuration is a private trust boundary; reject unsafe link origins.
  for f in (data/'rate').glob('*.json'):f.unlink()
  assert c.login(new)[0]==200
  good_config=dict(config)
  for bad_url in ['http://example.test','https://user@example.test','https://example.test/?x=1','https://example.test/#x']:
   config['baseUrl']=bad_url;(data/'recovery-config.json').write_text(json.dumps(config));assert c.req('recoveryStatus')[1]['mailConfigured'] is False
   assert admin.req('requestRecovery',{'email':'owner@example.test'})[0]==200
  config=good_config;(data/'recovery-config.json').write_text(json.dumps(config))
  check('invalid_recovery_origins_rejected_and_generic_request_preserved')
  assert admin.req('resetPassword',{'token':[],'password':new,'confirm':new})[0] in [400,429]
  assert admin.req('login',{'password':[]})[0]==400
  check('malformed_payloads_rejected_without_type_errors')
  # Real PHP-backed browser flows; external fonts/requests are blocked.
  for f in (data/'rate').glob('*.json'):f.unlink()
  from playwright.sync_api import sync_playwright
  browser_results=[]
  with sync_playwright() as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
   context=browser.new_context(viewport={'width':390,'height':844})
   context.route('**/*',lambda route:route.continue_() if route.request.url.startswith('http://127.0.0.1:4192/') else route.abort())
   page=context.new_page();errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
   page.goto('http://127.0.0.1:4192/');page.locator('#forgot-password').click()
   page.locator('#recovery-form [name=email]').fill('missing@example.test');page.locator('#recovery-form [type=submit]').click()
   page.get_by_text('Se houver uma conta elegível',exact=False).wait_for();page.locator('#recovery-done').click()
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
   browser_results.append('responsive_forgot_password_generic_response')
   key2='c3'*32;(data/'admin-recovery.key').write_text(key2)
   page.locator('#forgot-password').click();page.locator('#admin-recovery').click()
   page.locator('#recovery-form [name=key]').fill(key2)
   for field in ['password','confirm']:page.locator('#recovery-form [name='+field+']').fill('Ui-synthetic-password-2026')
   page.locator('#recovery-form [type=submit]').click();page.locator('#recovery-done').click()
   page.locator('#auth-form [name=password]').fill('Ui-synthetic-password-2026');page.locator('#auth-form [type=submit]').click()
   page.get_by_role('heading',name='Meus livros',exact=True).wait_for()
   browser_results.append('admin_recovery_and_login_real_php')
   page.set_viewport_size({'width':1440,'height':1000});page.locator('#account-btn').click();page.locator('#configure-recovery').click()
   page.locator('#recovery-form [name=email]').fill('owner@example.test');page.locator('#recovery-form [name=password]').fill('Ui-synthetic-password-2026')
   page.locator('#recovery-form [type=submit]').click();page.locator('#recovery-done').wait_for()
   verification=token('verify');page.goto('http://127.0.0.1:4192/#recovery=verify.'+verification)
   page.locator('#recovery-form [type=submit]').click();page.get_by_text('E-mail confirmado.',exact=True).wait_for();page.locator('#recovery-done').click()
   assert not page.locator('#modal').evaluate('(e)=>e.open')
   browser_results.append('configure_and_verify_email_with_authenticated_account')
   other=Client();other.status();assert other.req('requestRecovery',{'email':'owner@example.test'})[0]==200
   reset=token('reset');page.goto('http://127.0.0.1:4192/#recovery=reset.'+reset)
   page.locator('#recovery-form').wait_for();assert page.evaluate('location.hash')==''
   for field in ['password','confirm']:page.locator('#recovery-form [name='+field+']').fill('Ui-final-password-2026')
   page.locator('#recovery-form [type=submit]').click();page.get_by_text('Senha redefinida. Entre novamente.',exact=True).wait_for();page.locator('#recovery-done').click()
   page.locator('#auth-form [name=password]').fill('Ui-final-password-2026');page.locator('#auth-form [type=submit]').click();page.get_by_role('heading',name='Meus livros',exact=True).wait_for()
   browser_results.append('reset_password_token_fragment_removed_and_login')
   assert not errors,errors
   browser_results.append('no_javascript_runtime_errors')
   browser.close()
  (ROOT/'reports/auth-browser-tests.json').write_text(json.dumps({'local_php':True,'external_requests_blocked':True,'passed':browser_results},indent=2))
  print(len(browser_results),'real PHP browser scenarios passed',flush=True)
 finally:
  import signal
  os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=10);log.close()
(ROOT/'reports/auth-recovery-tests.json').write_text(json.dumps({'real_mail_sent':False,'real_host_modified':False,'php_workers':4,'passed':results},indent=2))
print(len(results),'authentication scenarios passed')
