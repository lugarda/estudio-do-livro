const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const T=require('../public/tools.js');
const dir=process.env.EXISTING_BOOKS;
if(dir){for(const name of fs.readdirSync(dir).filter(n=>n.endsWith('.json'))){
 test('existing project roundtrip preserves all saved fields: '+name,()=>{
  const original=JSON.parse(fs.readFileSync(path.join(dir,name),'utf8')),text=JSON.stringify(original),upgraded=T.upgradeBook(original);
  assert.equal(upgraded.id,original.id);assert.equal(upgraded.revision,original.revision);
  assert.deepEqual(upgraded.cover,original.cover);assert.deepEqual(upgraded.print,original.print);
  assert.deepEqual(upgraded.pages,original.pages);assert.deepEqual(upgraded.pageAssets,original.pageAssets);
  const normalized=JSON.parse(JSON.stringify(upgraded));if(!Object.hasOwn(original.layout,'titlePage'))delete normalized.layout.titlePage;
  normalized.chapters.forEach((c,i)=>{if(!Object.hasOwn(original.chapters[i],'showTitle'))delete c.showTitle;});
  assert.deepEqual(normalized,original);assert.equal(JSON.stringify(original),text);
 });
}}
test('current importers remain available',()=>{for(const name of ['parseDocx','parseRtf','parseOdt','parseEpub'])assert.equal(typeof T[name],'function');});
