# Diagnóstico e relatório — Estúdio do Livro 1.1.2

## O que foi comprovado sobre o login

O api.php da versão 1.1.1 é idêntico byte a byte ao backup público enviado anteriormente. O ZIP incremental 1.1.1 não continha api.php nem account.json. Não havia cadastro, verificação ou recuperação por e-mail. A validação da senha usa password_verify com o hash de account.json da pasta privada; não é possível recuperar a senha antiga a partir desse hash.

Reproduzimos localmente: oito tentativas incorretas ativam bloqueio por IP por 900 segundos, que impede inclusive uma tentativa correta durante esse período. Também há respostas distintas para CSRF expirado, conta ausente e senha incorreta. Caminho errado, arquivo de conta diferente, cookies/sessões e arquivos antigos em cache são hipóteses a conferir, não causas confirmadas.

Não acessamos credenciais atuais, não testamos senhas reais e não modificamos a hospedagem. Não é possível atribuir a falha à senha/hash nem confirmar a causa remota com os dados disponíveis. O guia inclui uma sequência de diagnóstico sem recriar conta ou dados.

## Implementação incremental

- Link Esqueci minha senha sob o campo de login e formulários responsivos no mesmo modal/visual existente.
- Cadastro de e-mail exige sessão autenticada, senha atual e confirmação explícita pelo link recebido. Campos de e-mail/autoria dos livros nunca são usados para inferir titularidade.
- Tokens aleatórios de 256 bits, hashes SHA-256 armazenados na conta privada, expiração de 30 minutos, finalidade e vínculo à versão da senha, consumo atômico. Não são armazenados em texto puro no servidor da aplicação.
- URLs de recuperação usam base HTTPS configurada privadamente; não usam o cabeçalho Host recebido. Tokens em fragmento são removidos da barra e enviados ao endpoint só em POST com CSRF; não aparecem no GET do servidor.
- Resposta idêntica para pedido de recuperação elegível, endereço desconhecido, indisponibilidade de configuração e limite de solicitações. Não há lista pública de e-mails nem distinção por status HTTP nessas situações. Isto não é certificação de resistência absoluta à análise de tempo da rede: a entrega ao mail() é síncrona.
- Limites por IP para solicitações, validação de tokens e troca de e-mail; limite global de solicitações para conter abuso distribuído. Respeita o bloqueio de login existente.
- Lock de arquivo compartilhado entre workers protege transições da conta/limites/tokens. Escrita atômica da conta com temporários privados (umask 0077); campos desconhecidos da conta são preservados. Alterações de segurança não escrevem em livros, perfis ou publicações.
- Redefinição invalida tokens e sessões existentes em todos os logins e limpa o bloqueio de login do IP que concluiu a recuperação. Outros IPs continuam sujeitos aos próprios limites. Nenhum token autentica automaticamente o proprietário.
- Recuperação administrativa exige chave aleatória criada manualmente em arquivo privado no cPanel, validade de 30 minutos, consumo persistido por hash e remoção do arquivo. Não existe senha mestre, endpoint de redefinição sem prova ou redefinição só com um e-mail digitado.
- Sessões PHP estritas e cookies existentes Secure em HTTPS, HttpOnly, SameSite Strict e sem Domain compartilhado.

## Preservação e escopo

Substituir somente api.php, app.js, index.html, ler.html; adicionar auth-recovery.php. O pacote não contém data, account.json, livros, publicações, chaves ou configuração ativa. Permanecem iguais à 1.1.1 os renderizadores, importadores, fontes e módulos de exportação. Não alterar vendor nem os outros subdomínios. Não há instalação, cron ou operação no WordPress.

A atualização faz as sessões antigas entrarem novamente. Para utilizar a senha antiga, o hash/caminho precisam estar corretos; a recuperação administrativa altera somente a senha da mesma conta, não cria outra conta. Novas senhas ficam limitadas a 12–72 bytes para evitar truncamento silencioso pelo bcrypt. Senhas antigas continuam aceitas pelo login existente até 200 bytes; recomenda-se redefinir as muito longas.

## Testes desta versão

- 26 testes Node de importação, PDF/EPUB, segurança de HTML, fontes e páginas manuais: passaram.
- 14 grupos de autenticação em PHP local com quatro workers: passaram. Incluem CSRF, posse da conta/caixa, hash/expiração/uso único, payloads inválidos, origem segura dos links, limites, recuperação administrativa, revogação de sessões e corrida com dois workers/sessões usando o mesmo token (um sucesso, uma recusa).
- 5 cenários de navegador contra a API PHP real local: passaram. Incluem interface a 390 px, desktop, login, e-mail confirmado, chave administrativa, redefinição e ausência de erros JavaScript. Requisições externas bloqueadas.
- 4 grupos de compatibilidade da API com cópias dos dois projetos enviados, incluindo salvar/conflito, perfil e publicação/leitura/retirada local: passaram. Conta sintética; nenhum dado de autenticação real reutilizado.
- PHP lint e node --check: passaram. Novos arquivos ZIP serão verificados por CRC, inventário e SHA-256 antes da distribuição e novamente após download público.

Execução local em PHP 8.4, não no PHP 8.3 da HostGator. O código requer PHP 8.2+ por causa do baseline existente (never); recomenda-se manter o PHP 8.3 informado e homologar ali. O teste local não atesta configuração/entrega do provedor.

## Pendências de homologação

- Conferir versão/extensões PHP, sessões/cookies, HTTPS, relógio do servidor, caminho privado, permissões de leitura/gravação/rename/flock e exclusão de cache para api.php.
- Verificar mail(), limites de envio, remetente autorizado, SPF/DKIM/DMARC e entrega real/spam. O pacote usa mail() e não implementa SMTP autenticado. Não há fila persistente de e-mail; se a entrega ao serviço falhar, o token desse pedido é invalidado. Uma mensagem aceita pode ainda não chegar.
- Ativar recuperação por e-mail só após configuração privada e autorização para teste real. O teste usa sendmail falso que grava somente numa pasta temporária local apagada ao terminar; nenhum e-mail real foi enviado.
- O backup enviado tinha pastas de perfis/publicações vazias; registros sintéticos foram usados nesses testes. Conferir links reais em leitura, sem republicar/excluir como teste.
- A conta privada é atualizada legitimamente quando você conclui a recuperação; não restaurar account.json antigo para desfazer frontend. Não há promessa de diagnóstico remoto confirmado nem de aplicativo isento de qualquer falha.
