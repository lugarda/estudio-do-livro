from pathlib import Path
import zipfile,json,hashlib
ROOT=Path(__file__).resolve().parents[1];DIST=ROOT/'dist';DIST.mkdir(exist_ok=True)
runtime=['api.php','app.js','auth-recovery.php','index.html','ler.html']
manifest={'version':'1.1.2','base':'1.1.1','replace':['api.php','app.js','index.html','ler.html'],'add':['auth-recovery.php'],'preserve':['data','account.json','books','profiles','publication','published','rate','vendor','.htaccess','.user.ini','php.ini'],'files':{n:hashlib.sha256((ROOT/'public'/n).read_bytes()).hexdigest() for n in runtime}}
(ROOT/'reports/auth-release-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def pack(name,entries):
 path=DIST/name
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,source in entries:
   assert not name.startswith('/') and '..' not in Path(name).parts
   info=zipfile.ZipInfo(name,date_time=(2026,11,6,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
   z.writestr(info,source.read_bytes())
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  assert len(z.namelist())==len(set(z.namelist()))
  for name,source in entries:assert z.read(name)==source.read_bytes()
 return path
app=pack('estudio-do-livro-1.1.2-cpanel.zip',[(n,ROOT/'public'/n) for n in runtime])
guides=['RECUPERACAO-CPANEL-1.1.2.md','DIAGNOSTICO-1.1.2.md','TESTES-1.1.2.md','exemplos/recovery-config.example.json','ferramentas/gerar-chave.html','reports/auth-release-manifest.json','reports/auth-recovery-tests.json','reports/auth-browser-tests.json','reports/node-tests-1.1.2.txt','reports/php-api-compat.json','tests/auth-recovery.py','tests/php-api-compat.py','tests/export.test.cjs','tests/existing-projects.test.cjs','tools/build-auth-release.py']
guide=pack('estudio-do-livro-1.1.2-guias.zip',[(n,ROOT/n) for n in guides])
(DIST/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in [app,guide]))
print((DIST/'SHA256SUMS.txt').read_text())
print('CRC and byte equality checked; runtime entries:',runtime)
