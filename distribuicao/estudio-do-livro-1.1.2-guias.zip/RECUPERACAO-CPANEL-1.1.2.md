# Estúdio do Livro 1.1.2 — instalação e recuperação da conta atual

Nenhuma alteração na hospedagem foi realizada. Atualização incremental **sobre 1.1.1**.
Não é uma instalação completa. Não aplicar em outro diretório ou em outra versão sem comparar.

## Antes de atualizar

1. Salve o trabalho, feche todas as abas do Estúdio e faça novos backups privados da instalação pública e de `/home2/edua3052/data`. Guarde-os fora dos sites publicados. Não envie backups, senhas ou chaves ao chat/GitHub.
2. Confirme no cPanel > Domínios a raiz `/home2/edua3052/estudiodolivro.eduardogoncalvespsico.com`. Ela deve conter api.php e index.html diretamente. Não alterar o WordPress nem outros subdomínios.
3. Confirme que api.php atual ainda usa `dirname(__DIR__).'/data'`. Se tiver código/configuração diferente do backup, interrompa para comparação. Não mude o caminho dos dados.
4. Verifique SHA256SUMS.txt no computador e extraia o ZIP primeiro numa pasta privada de conferência, fora de data e fora dos diretórios publicados.

## Copiar manualmente pelo Gerenciador do cPanel

- **Adicionar primeiro:** `auth-recovery.php`, ao lado de api.php.
- **Substituir:** `api.php`, `app.js`, `index.html`, `ler.html`, exclusivamente na raiz do Estúdio. Os dois HTML devem ser copiados por último.
- Manter todos os módulos, fontes e dependências da 1.1.1. Não substituir vendor, não modificar .htaccess/.user.ini/php.ini.
- O pacote não contém data, account.json, install.key, chave administrativa, configuração ativa de e-mail, livros ou publicações.
- Não apagar, substituir, mover ou recriar data nem qualquer livro, perfil ou publicação.
- Atualizar o navegador; se necessário, limpar só o cache do subdomínio do Estúdio. Os HTML usam `?v=1.1.2`.

Todas as sessões antigas precisarão entrar novamente. Isso é esperado; não significa perda da conta.
Se aparecer **Criar acesso** inesperadamente ou lista de livros vazia, pare. Não crie conta nova, não use install.key e não restaure data por cima dos dados atuais para tentar corrigir.

## Diagnosticar antes de redefinir

Tente apenas uma vez com a senha que você sabe ser correta, depois de aguardar 15 minutos desde o último bloqueio. Confira Caps Lock, teclado e preenchimento automático. Não envie a senha a terceiros.
No navegador > Ferramentas do desenvolvedor > Rede, observe apenas o código e a mensagem da resposta `api.php?action=login`:

- 401 / Senha incorreta: o hash encontrado não corresponde à senha informada. Pode ser conta/diretório diferente; não há prova de que a atualização mudou a senha.
- 429: bloqueio por tentativas; aguarde. Não apague os controles rate para contornar.
- 403 / sessão expirou: atualize a página e confira cookies e HTTPS. Cache/CDN não pode armazenar api.php.
- 409 / conta não configurada ou tela Criar acesso: confira raiz do domínio e presença de account.json na pasta privada, sem editar/expor seu conteúdo.
- 500 ou resposta HTML em vez de JSON: consultar logs PHP do cPanel sem registrar senhas, hashes, cookies ou corpos de requisição. Conferir PHP 8.3, módulos session/json, gravação das sessões e permissões privadas.
- 200 seguido de volta ao login: verificar cookie host-only estudio_livro, Secure/HttpOnly/SameSite=Strict, HTTPS e persistência de sessões. Não desativar essas proteções.

Não é necessário chamar endpoints ou efetuar redefinição para conferir caminhos e logs. O diagnóstico remoto exato continua pendente: não tentamos entrar na sua conta e não lemos o arquivo atual da hospedagem.

## Recuperação administrativa sem e-mail (prova de controle do cPanel)

1. Acesse seu próprio cPanel pela conexão segura habitual. Confirme que está no diretório privado correto. Preserve account.json; não editar o hash manualmente.
2. No computador, extraia o ZIP de guias e abra `ferramentas/gerar-chave.html` localmente. Clique em Gerar: o navegador cria uma chave aleatória de 256 bits, sem rede, sem enviar ou guardar a chave. Não use exemplos ou texto escolhido manualmente como chave.
3. Pelo Gerenciador de Arquivos, **crie somente o arquivo novo** `/home2/edua3052/data/admin-recovery.key`. Conteúdo: apenas os 64 caracteres hexadecimais gerados, em uma linha. Não substitua account.json, install.key ou outro arquivo. Use permissão 0600 (leitura/escrita do proprietário). A pasta precisa continuar privada, fora de todas as raízes públicas.
4. A chave vale por **30 minutos a partir da modificação do arquivo**. Crie/salve o arquivo agora; não use um arquivo antigo ou backup com data antiga. Não publique nem compartilhe a chave.
5. Abra o Estúdio via HTTPS > Esqueci minha senha > Não tenho e-mail configurado: recuperação pelo cPanel. Cole a chave e informe/repita uma nova senha forte de 12 a 72 bytes. Acentos podem ocupar mais de um byte. Use gerenciador de senhas; nenhuma senha de exemplo deve ser usada.
6. Após a confirmação, a chave é consumida e o aplicativo tenta remover o arquivo. Confira pelo cPanel e remova **somente admin-recovery.key** se tiver permanecido. O hash de consumo impede reutilização mesmo que esse arquivo não tenha sido removido.
7. Entre normalmente com a nova senha. As sessões antigas e links pendentes ficam inválidos. A senha anterior deixa de funcionar. Confira livros/perfis/publicações primeiro em leitura; não publique livros reais como teste.
8. Para abandonar uma tentativa, remova somente o arquivo temporário admin-recovery.key. Nunca remova account.json, livros ou a pasta data.

Essa recuperação só modifica os campos de autenticação da conta atual, preservando os demais campos. O código não escreve em livros, perfis ou publicações durante a redefinição.

## Habilitar recuperação por e-mail posteriormente

Não há e-mail cadastrado/verificado no modelo antigo. É obrigatório comprovar a caixa antes de usá-la para redefinição. Não inferimos e-mail de autor ou de projetos.

1. Confirme com a HostGator que `mail()` do PHP está habilitado neste subdomínio, os limites de envio e o remetente permitido. Configure/valide SPF, DKIM e DMARC conforme o serviço. Aceitação por mail() não garante chegada à caixa.
2. Após sua aprovação, crie **um arquivo privado novo** `/home2/edua3052/data/recovery-config.json`, permissão 0600, usando o exemplo do ZIP de guias. Não copie esse arquivo para o diretório público.
3. Ajuste `from` para um remetente real autorizado pela hospedagem, mantenha `baseUrl` como `https://estudiodolivro.eduardogoncalvespsico.com` e só então use `enabled: true`. Não há senha SMTP ou integração SMTP nesta versão.
4. Entre com a senha atual > ícone Conta > E-mail de recuperação. Informe o endereço e a senha atual. Abra o link recebido e confirme explicitamente. Até essa confirmação, esse endereço não serve para recuperação. Se já houver outro e-mail verificado, continua válido até concluir a troca.
5. O link contém token aleatório com validade de 30 minutos e uso único. O token fica no fragmento da URL, é retirado da barra pelo aplicativo e enviado ao servidor somente em POST com CSRF; o servidor armazena apenas seu hash.
6. Depois de verificado, use Esqueci minha senha. A resposta é genérica mesmo para endereço desconhecido, sem configuração ou pedido limitado. Não concluir que a entrega funcionou só por essa resposta.
7. Confirme entrega/spam e remetente com uma caixa controlada por você, somente quando autorizar esse teste real. Nenhum e-mail real foi enviado nesta entrega.

Sem configuração ativa, a recuperação por e-mail permanece indisponível e não faz envios. A recuperação administrativa continua independente do e-mail.

## Conferência e retorno

Após instalar, testar login/saída, recuperação administrativa se necessária, preservação dos livros, edição/exportação em projeto fictício, leitura de links publicados já existentes e e-mail somente após configuração/autorização.
Não há cron, banco de dados ou migração de livros a executar.

Para retornar à 1.1.1, reponha apenas os quatro arquivos públicos substituídos a partir do seu backup; o módulo extra pode permanecer sem referência. **Não restaure o account.json antigo:** isso reativaria a senha antiga e perderia alterações de segurança. Não restaure data por cima do conteúdo atual. O frontend/API antigo não oferece recuperação nem revogação de sessões da 1.1.2; evite rollback depois de incidente de segurança sem revisão.
