# Reproduzir os testes localmente

Não executar estes testes na hospedagem nem sobre data real.

Requisitos: Node com suporte a `node:test` e à opção `--test-isolation=none`, Python 3 com Playwright/pypdf, Chromium e PHP CLI com session/json e mail habilitado. Bibliotecas/módulos da instalação 1.1.1 precisam estar presentes na pasta public. Aplicar o patch local sobre uma cópia completa da 1.1.1; os testes não incluem livros ou autenticação do proprietário.

```
node --test --test-isolation=none tests/*.test.cjs
PHP_BIN=/caminho/confirmado/php python3 tests/auth-recovery.py
```

O teste auth-recovery cria uma pasta temporária, conta sintética, caixa local de e-mail e quatro workers PHP escutando somente 127.0.0.1:4192. Encerra os workers e remove os dados temporários ao terminar. O navegador bloqueia pedidos externos. O binário Chromium usado pelo teste é /usr/bin/chromium; ajustar localmente se necessário. As bibliotecas Python não são instaladas automaticamente.

Para os testes opcionais dos projetos existentes/API, use exclusivamente cópias JSON privadas de projetos fictícios via EXISTING_BOOKS, nunca account.json. O teste php-api-compat também precisa de duas cópias JSON de projetos válidos para reproduzir os casos registrados; o arquivo fornecido não contém esses dados. Não versionar esses fixtures privados.

Relatórios anexos correspondem às execuções locais desta versão; não são resultados da HostGator.
