(async function(){'use strict';
const T=window.BookTools,root=document.querySelector('#book-reader');
try{
  const token=new URL(location.href).searchParams.get('token');
  if(!/^[a-f0-9]{64}$/.test(token||''))throw Error('Este link não é válido.');
  const u=new URL('api.php',location.href);u.searchParams.set('action','read');u.searchParams.set('token',token);
  const res=await fetch(u,{credentials:'omit'}),data=await res.json();
  if(!res.ok||!data.ok)throw Error(data.error||'Este livro não está disponível.');
  const b=data.book,l=b.layout||{};
  document.title=(b.title||'Livro')+' · Leitura';
  root.style.fontFamily=l.font==='sans'?'Arial,sans-serif':l.font==='mono'?'monospace':'Georgia,serif';
  root.style.fontSize=(Number(l.fontSize)>=7&&Number(l.fontSize)<=36?Number(l.fontSize):16)+'pt';
  root.style.textAlign=['left','center','right','justify'].includes(l.align)?l.align:'left';
  const safeImage=/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=\s]+$/i.test(b.cover?.image||'')?'<img src="'+T.esc(b.cover.image)+'" alt="Capa do livro" style="display:block;max-width:240px;max-height:320px;width:auto;margin:0 auto 25px">':'';
  const toc='<nav aria-label="Sumário"><h2>Sumário</h2><ol>'+(b.chapters||[]).map((c,i)=>'<li><a href="#capitulo-'+i+'">'+T.esc(c.title||'Capítulo')+'</a></li>').join('')+'</ol></nav>';
  const chapters=(b.chapters||[]).map((c,i)=>'<article id="capitulo-'+i+'">'+(c.showTitle===false?'':'<h2>'+T.esc(c.title||'Capítulo')+'</h2>')+T.cleanHtml(c.html)+'</article>').join('');
  const pageAssets=new Map((b.pageAssets||[]).map(asset=>[asset.id,asset]));
  const pages=(b.pages||[]).map((page,i)=>{const asset=pageAssets.get(page.assetId);if(!asset)return '<article class="reader-imported-page"><h2>Página importada '+(i+1)+'</h2><p>Arquivo de página indisponível.</p></article>';const title=T.esc((asset.name||'Página')+(page.kind==='pdf'?' · Página '+page.sourcePage:''));if(page.kind==='image'&&/^data:image\/(png|jpeg);base64,/i.test(asset.data||''))return '<article class="reader-imported-page"><h2>Página importada '+(i+1)+'</h2><img src="'+T.esc(asset.data)+'" alt="'+title+'" style="display:block;max-width:100%;height:auto;margin:18px auto"></article>';if(page.kind==='pdf')return '<article class="reader-imported-page"><h2>Página importada '+(i+1)+'</h2><p>'+title+'</p><canvas data-reader-pdf="'+T.esc(asset.id)+'" data-source-page="'+page.sourcePage+'" aria-label="'+title+'"></canvas></article>';return '<article class="reader-imported-page"><h2>Página importada '+(i+1)+'</h2><p>Formato de página não disponível.</p></article>';}).join('');
  const header='<header>'+safeImage+'<div style="font:600 11px Arial;letter-spacing:.16em;color:#b45c43">LEITURA ON-LINE</div><h1>'+T.esc(b.title||'Sem título')+'</h1><p>'+T.esc(b.subtitle||'')+'</p><p>'+T.esc(b.author||'')+'</p></header>';
  root.innerHTML=header+(l.tocPosition==='none'?chapters+pages:l.tocPosition==='after'?chapters+pages+toc:toc+chapters+pages)+'<p style="text-align:center;font:12px Arial;color:#777;margin-top:50px">Livro criado no Estúdio do Livro</p>';
  const pdfCanvases=[...root.querySelectorAll('canvas[data-reader-pdf]')];if(pdfCanvases.length){const pdfjs=await import('./vendor/pdf.min.mjs');pdfjs.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdf.worker.min.mjs',location.href).href;const docs=new Map();for(const canvas of pdfCanvases){try{const asset=pageAssets.get(canvas.dataset.readerPdf);if(!asset)throw Error('Arquivo de página indisponível.');let pdf=docs.get(asset.id);if(!pdf){const encoded=(asset.data||'').split(',')[1];if(!encoded)throw Error('O PDF da página está inválido.');pdf=await pdfjs.getDocument({data:Uint8Array.from(atob(encoded),c=>c.charCodeAt(0))}).promise;docs.set(asset.id,pdf);}const page=await pdf.getPage(Number(canvas.dataset.sourcePage)),base=page.getViewport({scale:1}),viewport=page.getViewport({scale:Math.min(1.3,900/base.width)});canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);canvas.style.display='block';canvas.style.maxWidth='100%';canvas.style.height='auto';canvas.style.margin='18px auto';await page.render({canvasContext:canvas.getContext('2d'),viewport}).promise;}catch(error){canvas.insertAdjacentHTML('afterend','<p>'+T.esc(error.message||'Não foi possível exibir esta página.')+'</p>');canvas.remove();}}for(const pdf of docs.values())pdf.destroy?.();}
}catch(err){root.innerHTML='<div class="empty" style="color:#333"><div><h3>Livro indisponível</h3><p>'+T.esc(err.message)+'</p></div></div>';}
})();
