(function(root){'use strict';
const cache=new Map();
const names={serif:['EBGaramond-Regular','EBGaramond-Bold','EBGaramond-Italic','EBGaramond-BoldItalic'],sans:['Lato-Regular','Lato-Bold','Lato-Italic','Lato-BoldItalic'],mono:['DejaVuSansMono','DejaVuSansMono-Bold','DejaVuSansMono-Oblique','DejaVuSansMono-BoldOblique']};
root.BookFonts={async load(family){family=names[family]?family:'serif';if(!cache.has(family))cache.set(family,Promise.all(names[family].map(async name=>{const r=await fetch(new URL('vendor/fonts/'+name+'.ttf',document.baseURI));if(!r.ok)throw Error('Não foi possível carregar a fonte '+name+'. Reenvie a pasta vendor/fonts completa.');return new Uint8Array(await r.arrayBuffer());})).catch(e=>{cache.delete(family);throw e;}));return cache.get(family);}};
})(window);
