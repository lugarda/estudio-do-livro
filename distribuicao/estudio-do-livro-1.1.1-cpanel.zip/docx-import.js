(function(root){'use strict';
const T=root.BookTools,W='http://schemas.openxmlformats.org/wordprocessingml/2006/main',R='http://schemas.openxmlformats.org/officeDocument/2006/relationships',A='http://schemas.openxmlformats.org/drawingml/2006/main';
const children=(el,name)=>[...(el?.children||[])].filter(x=>x.namespaceURI===W&&x.localName===name);
const child=(el,name)=>children(el,name)[0],val=(el,name)=>child(el,name)?.getAttributeNS(W,'val');
const attr=(el,name)=>el?.getAttributeNS(W,name);
const enabled=el=>!!el&&!['0','false','off'].includes(attr(el,'val'));
function props(p,r){const out={};
 const align=val(p,'jc');if(align)out.align=align==='both'?'justify':align;
 const sp=child(p,'spacing');for(const[k,a]of[['before','before'],['after','after']])if(attr(sp,a)!==null&&attr(sp,a)!==undefined)out[k]=Number(attr(sp,a))/20;
 if(attr(sp,'line'))out.line=attr(sp,'lineRule')==='auto'||!attr(sp,'lineRule')?Number(attr(sp,'line'))/240:null;
 const ind=child(p,'ind');if(attr(ind,'firstLine')!==null&&attr(ind,'firstLine')!==undefined)out.indent=Number(attr(ind,'firstLine'))*25.4/1440;
 if(child(p,'keepNext'))out.keep=enabled(child(p,'keepNext'));if(child(p,'pageBreakBefore'))out.breakBefore=enabled(child(p,'pageBreakBefore'));
 const f=child(r,'rFonts'),font=attr(f,'ascii')||attr(f,'hAnsi');if(font)out.font=font;
 if(val(r,'sz'))out.size=Number(val(r,'sz'))/2;
 if(val(r,'color'))out.color=val(r,'color');
 for(const[k,n]of[['bold','b'],['italic','i'],['underline','u'],['strike','strike']])if(child(r,n))out[k]=enabled(child(r,n))&&val(r,n)!=='none';
 return out;
}
const family=f=>/lato|arial|calibri|helvetica|sans/i.test(f||'')?'sans':/courier|mono/i.test(f||'')?'mono':'serif';
function htmlAttrs(p){let s='';const add=(k,v)=>{s+=' '+k+'="'+T.esc(v)+'"';};
 if(['left','center','right','justify'].includes(p.align))add('data-align',p.align);
 if(p.font)add('data-font-family',family(p.font));
 for(const[k,n,min,max]of[['size','data-text-size',7,72],['line','data-line-height',.8,3],['before','data-space-before',0,200],['after','data-space-after',0,200],['indent','data-indent',0,30]])if(Number.isFinite(p[k])&&p[k]>=min&&p[k]<=max)add(n,Math.round(p[k]*1000)/1000);
 if(/^[a-f0-9]{6}$/i.test(p.color||''))add('data-color',p.color);if(p.keep)add('data-keep-next','true');if(p.breakBefore)add('data-page-break-before','true');return s;
}
T.parseDocx=async function(file){
 const zip=await root.JSZip.loadAsync(file);const files=Object.values(zip.files);let total=0;
 if(files.length>2000)throw Error('O Word contém arquivos demais para importação segura.');
 for(const f of files){total+=f._data?.uncompressedSize||0;if(total>48*1024*1024)throw Error('O Word descompactado ultrapassa 48 MB.');}
 async function xml(path,required=false){const f=zip.file(path);if(!f){if(required)throw Error('Arquivo Word inválido: '+path);return null;}const source=await f.async('string');if(source.length>8*1024*1024||/<!DOCTYPE|<!ENTITY/i.test(source))throw Error('O XML do Word não é seguro ou é grande demais.');const d=new DOMParser().parseFromString(source,'application/xml');if(d.querySelector('parsererror'))throw Error('XML inválido no documento Word.');return d;}
 const doc=await xml('word/document.xml',true),styles=await xml('word/styles.xml'),relsDoc=await xml('word/_rels/document.xml.rels'),rels={};
 for(const el of [...(relsDoc?.getElementsByTagName('Relationship')||[])])rels[el.getAttribute('Id')]={target:el.getAttribute('Target'),external:el.getAttribute('TargetMode')==='External',type:el.getAttribute('Type')||''};
 const definitions=new Map(),cache=new Map();for(const s of [...(styles?.getElementsByTagNameNS(W,'style')||[])])definitions.set(attr(s,'styleId'),s);
 const defaultProps=props(styles?.getElementsByTagNameNS(W,'pPrDefault')[0]?.firstElementChild,styles?.getElementsByTagNameNS(W,'rPrDefault')[0]?.firstElementChild);
 function style(id,seen=new Set()){if(cache.has(id))return cache.get(id);if(seen.has(id))return {};seen.add(id);const s=definitions.get(id);if(!s)return {};const p={...style(val(s,'basedOn'),seen),...props(child(s,'pPr'),child(s,'rPr'))};cache.set(id,p);return p;}
 const warnings=[],body=doc.getElementsByTagNameNS(W,'body')[0];if(!body)throw Error('O Word não contém corpo de texto.');
 const paragraphs=[...body.children],records=[];let imageCount=0;
 async function renderRun(run,base){const p={...base,...props(null,child(run,'rPr'))};let out='';
 for(const item of [...run.children]){
  if(item.localName==='t'||item.localName==='instrText'){if(item.localName==='t')out+=T.esc(item.textContent);}
  else if(item.localName==='tab')out+='\u2003';
  else if(item.localName==='br')out+=attr(item,'type')==='page'?'<span data-page-break-after="true"></span>':'<br>';
  else if(item.localName==='drawing'){
   for(const blip of [...item.getElementsByTagNameNS(A,'blip')]){
    const rel=rels[blip.getAttributeNS(R,'embed')];if(!rel||rel.external||!rel.type.endsWith('/image')){warnings.push('Uma imagem externa não foi carregada.');continue;}
    const target=rel.target.replace(/^\//,'').replace(/^word\//,'');if(target.split('/').includes('..')||!/^media\/[A-Za-z0-9_. -]+\.(png|jpe?g)$/i.test(target)){warnings.push('Uma imagem não PNG/JPG foi omitida.');continue;}
    const img=zip.file('word/'+target);if(!img)continue;const ext=/\.png$/i.test(target)?'png':'jpeg',alt=item.getElementsByTagName('*');let label='Imagem importada';for(const a of [...alt])if(a.localName==='docPr')label=a.getAttribute('descr')||a.getAttribute('name')||label;
    const extent=[...item.getElementsByTagName('*')].find(x=>x.localName==='extent'&&x.hasAttribute('cx'));const widthMm=extent?Number(extent.getAttribute('cx'))/36000:null;
    out+='<img '+(widthMm>0&&widthMm<=500?'data-width-mm="'+widthMm.toFixed(3)+'" ':'')+'src="data:image/'+ext+';base64,'+await img.async('base64')+'" alt="'+T.esc(label)+'" data-size="100" data-align="center">';imageCount++;
   }
  }
 }
 if(p.bold)out='<strong>'+out+'</strong>';if(p.italic)out='<em>'+out+'</em>';if(p.underline)out='<u>'+out+'</u>';if(p.strike)out='<s>'+out+'</s>';
 return '<span'+htmlAttrs({size:p.size,font:p.font,color:p.color})+'>'+out+'</span>';
 }
 for(const el of paragraphs){
  if(el.localName==='tbl'){const text=[...el.getElementsByTagNameNS(W,'t')].map(x=>x.textContent).join(' ');records.push({html:'<p>'+T.esc(text)+'</p>',text,style:{}});warnings.push('Tabelas foram convertidas em texto; confira-as no original.');continue;}
  if(el.localName!=='p')continue;
  const pp=child(el,'pPr'),styleId=val(pp,'pStyle')||'Normal',p={...defaultProps,...style('Normal'),...style(styleId),...props(pp,child(pp,'rPr'))};
  const runBase={...p},runs=[...el.getElementsByTagNameNS(W,'r')];if(runs[0]){const first=props(null,child(runs[0],'rPr'));for(const key of ['font','size'])if(first[key]!==undefined)p[key]=first[key];}
  let html='';for(const node of [...el.children]){
   if(node.localName==='r')html+=await renderRun(node,runBase);
   else if(node.localName==='hyperlink'){
    const rel=rels[node.getAttributeNS(R,'id')],anchor=attr(node,'anchor'),href=anchor?'#doc-'+anchor:rel?.target||'';let inner='';for(const run of children(node,'r'))inner+=await renderRun(run,runBase);
    html+=(/^https?:\/\//i.test(href)||/^#doc-[A-Za-z0-9_.-]+$/.test(href))?'<a href="'+T.esc(href)+'">'+inner+'</a>':inner;
   }
  }
  const text=[...el.getElementsByTagNameNS(W,'t')].map(n=>n.textContent).join('');
  const bookmark=[...el.getElementsByTagNameNS(W,'bookmarkStart')].map(n=>attr(n,'name')).find(n=>n&&!n.startsWith('_'));
  const pageBreak=[...el.getElementsByTagNameNS(W,'br')].some(b=>attr(b,'type')==='page');
  const section=child(pp,'sectPr');
  const heading=/^(Heading[1-4]|T[ií]tulo[1-4]|Títuloeditorial)$/i.test(styleId)||/^(CAP[IÍ]TULO\s+\d+|EP[IÍ]LOGO|PR[ÓO]LOGO)$/i.test(text.trim());
  const tag=heading?'h2':'p',anchor=bookmark&&/^[A-Za-z0-9_.-]{1,90}$/.test(bookmark)?' id="doc-'+T.esc(bookmark)+'"':'';
  if(!text.trim()&&!/<img\b/i.test(html)&&!pageBreak&&!p.breakBefore&&!section)continue;
  html='<'+tag+htmlAttrs(p)+anchor+'>'+html+'</'+tag+'>';
  if(pageBreak)html=html.replace('data-page-break-after="true"','data-page-break-after="true"');
  records.push({html,text:text.trim(),style:p,section:!!section,pageBreak,heading,images:/<img\b/i.test(html)});
 }
 if(doc.getElementsByTagNameNS(W,'footnoteReference').length||doc.getElementsByTagNameNS(W,'endnoteReference').length)warnings.push('Notas de rodapé/fim exigem revisão no original; esta versão não reconstrói suas referências.');
 if(doc.getElementsByTagNameNS(W,'numPr').length)warnings.push('Confira listas numeradas e marcadores do Word após importar.');
 if(!records.some(r=>r.text||r.images))throw Error('O Word não contém texto ou imagens importáveis.');
 const sections=[...doc.getElementsByTagNameNS(W,'sectPr')],layout={};
 const sec=sections.find(s=>Number(attr(child(s,'pgMar'),'left'))>0)||sections[0];
 if(sec){const size=child(sec,'pgSz'),m=child(sec,'pgMar'),mm=v=>Math.round(Number(v)*25.4/1440*100)/100;
  for(const[k,a]of[['width','w'],['height','h']])if(attr(size,a))layout[k]=mm(attr(size,a));
  for(const[k,a]of[['marginTop','top'],['marginBottom','bottom'],['marginInner','left'],['marginOuter','right']])if(attr(m,a)!==null&&attr(m,a)!==undefined)layout[k]=mm(attr(m,a));
 }
 const normal={...defaultProps,...style('Normal'),...style('CorpodoLivro')};if(normal.font)layout.font=family(normal.font);if(normal.size)layout.fontSize=normal.size;if(normal.line)layout.lineHeight=normal.line;if(normal.align)layout.align=normal.align;if(normal.indent!==undefined)layout.paragraphIndent=normal.indent;
 layout.titlePage=false;layout.tocPosition='none';
 const cover={};
 function imageFrom(record){const m=record?.html.match(/src="(data:image\/(?:png|jpeg);base64,[^"]+)"/);return m?.[1];}
 // Separate only the image-only first/last leaves, confirmed in the import dialogue.
 if(records[0]?.images&&!records[0].text){cover.image=imageFrom(records.shift());cover.artworkContainsText=true;}
 if(records.at(-1)?.images&&!records.at(-1).text){cover.backImage=imageFrom(records.pop());cover.artworkContainsText=true;}
 while(records[0]&&!records[0].text&&!records[0].images)records.shift();
 const chapters=[];let cur={id:T.id(),title:'Elementos pré-textuais',showTitle:false,html:''};
 for(let i=0;i<records.length;i++){
  const r=records[i],chapter=/^(CAP[IÍ]TULO\s+\d+|EP[IÍ]LOGO|PR[ÓO]LOGO)$/i.test(r.text);
  if(chapter&&cur.html.trim()){chapters.push(cur);const next=records[i+1];cur={id:T.id(),title:r.text+(next?.text?' — '+next.text:''),showTitle:false,html:''};}
  if(r.section&&!r.text&&!r.images){cur.html+='<p data-page-break-after="true"></p>';continue;}
  if(!r.text&&!r.images&&r.pageBreak){cur.html+='<p data-page-break-after="true"></p>';continue;}
  cur.html+=r.html;
 }
 if(cur.html.trim())chapters.push(cur);
 const core=await xml('docProps/core.xml');const dc='http://purl.org/dc/elements/1.1/';const metadata={title:core?.getElementsByTagNameNS(dc,'title')[0]?.textContent||'',author:core?.getElementsByTagNameNS(dc,'creator')[0]?.textContent||''};
 if(sections.length>1)warnings.push('O Word tem '+sections.length+' seções. O miolo usa as margens da seção de texto; cabeçalhos, rodapés e paginação devem ser conferidos.');
 const unknownFonts=[...new Set(records.map(r=>r.style.font).filter(f=>f&&!/EB Garamond|Lato|Times New Roman|Arial|Courier/i.test(f)))];if(unknownFonts.length)warnings.push('Fontes substituídas por famílias disponíveis: '+unknownFonts.join(', ')+'.');
 if(cover.image||cover.backImage)warnings.push('Capa e contracapa em imagem foram separadas do miolo. Confira o recorte e a resolução antes de imprimir.');
 warnings.push('Texto e estilos suportados foram preservados. A paginação é recalculada: confira o PDF e atualize números de um sumário digitado no Word. No Kindle o texto é adaptável.');
 return {chapters:chapters.map(c=>({...c,html:T.cleanHtml(c.html)})),layout,cover,metadata,warnings:[...new Set(warnings)],stats:{paragraphs:records.length,chapters:chapters.length,images:imageCount,sections:sections.length}};
};
})(window);
