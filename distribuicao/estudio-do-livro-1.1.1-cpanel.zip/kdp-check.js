(function(root){'use strict';const T=root.BookTools;
T.rasterSize=function(src){try{if(!/^data:image\/(png|jpeg);base64,/.test(src||''))return null;const head=src.split(',')[1].slice(0,87380),b=Uint8Array.from(atob(head),c=>c.charCodeAt(0));if(b[0]===137&&b[1]===80&&b.length>=24){const d=new DataView(b.buffer);return {width:d.getUint32(16),height:d.getUint32(20)};}let i=2;while(i+8<b.length){if(b[i]!==255){i++;continue;}const m=b[i+1],len=(b[i+2]<<8)|b[i+3];if([192,193,194,195,197,198,199,201,202,203,205,206,207].includes(m))return {width:(b[i+7]<<8)|b[i+8],height:(b[i+5]<<8)|b[i+6]};if(len<2)break;i+=len+2;}}catch{}return null;};
T.kdpCheck=function(book,pages){const errors=[],warnings=[],l=book.layout,p=book.print,n=Number(pages),w=Number(l.width),h=Number(l.height);
 if(w<127||w>215.9||h<203.2||h>297)errors.push('O formato informado está fora da faixa usual de corte personalizado KDP (127–215,9 × 203,2–297 mm). Confirme o formato na sua edição.');
 if(!Number.isInteger(n)||n<1)errors.push('Gere a prévia para contar as páginas.');
 else{if(n<24)errors.push('O miolo tem menos de 24 páginas. Confira o mínimo do papel/tinta selecionados na KDP.');if(n>828)errors.push('O miolo supera 828 páginas. Confira o limite do formato/papel/tinta.');
  const gutter=n<=150?9.525:n<=300?12.7:n<=500?15.875:n<=700?19.05:22.225;
  if(Number(l.marginInner)+.02<gutter)errors.push('Margem interna insuficiente para '+n+' páginas: use pelo menos '+T.formatMm(gutter)+'.');}
 const hasBleed=['bleedLeft','bleedRight','bleedTop','bleedBottom'].some(k=>Number(p[k])>0),outer=hasBleed?9.525:6.35;
 for(const key of ['marginTop','marginBottom','marginOuter'])if(Number(l[key])+.02<outer)errors.push('Margens superior, inferior e externa precisam de pelo menos '+T.formatMm(outer)+' nesta configuração.');
 if(hasBleed)warnings.push('A sangria KDP do miolo é assimétrica: 3,175 mm na borda externa e nas bordas superior/inferior. Confira páginas pares/ímpares no Previewer; não use sangria da capa no miolo.');
 if(!root.BookFonts||!root.fontkit)errors.push('As fontes incorporáveis não estão disponíveis. Não enviar o PDF à KDP.');
 if((book.pages||[]).some(p=>p.kind==='pdf'))warnings.push('PDFs importados mantêm medidas/fontes originais e viram imagens no EPUB. Confira esses arquivos; esta verificação não certifica suas páginas.');
 if(!book.cover.image)warnings.push('Prepare uma imagem de capa para o e-book.');
 const assets=[];for(const [key,label]of [['image','Capa'],['backImage','Contracapa']]){const dim=T.rasterSize(book.cover[key]);if(dim){const dpi=Math.min(dim.width/(w/25.4),dim.height/(h/25.4));assets.push({label,...dim,dpi:Math.round(dpi)});if(dpi<300)errors.push(label+' com aproximadamente '+Math.round(dpi)+' dpi no tamanho do impresso. Prepare a arte original em pelo menos 300 dpi; ampliar pixels não recupera detalhes.');}}
 if(book.importInfo?.format==='docx')warnings.push('Confira se os números do sumário original ainda correspondem ao PDF repaginado.');
 warnings.push('Esta verificação não certifica aceitação. Confirme papel/tinta, limites do formato, resolução e dimensões finais da capa no calculador KDP; valide no Kindle Previewer e Print Previewer.');
 return {errors,warnings,assets,pages:n,format:{width:w,height:h}};
};})(window);
