(function(root){'use strict';
const T=root.BookTools;
const blocks=new Set(['P','DIV','H1','H2','H3','H4','LI','BLOCKQUOTE']);
const numeric={'data-text-size':[7,72],'data-line-height':[.8,3],'data-space-before':[0,200],'data-space-after':[0,200],'data-indent':[0,30]};
const attrNames=['data-align','data-font-family','data-color',...Object.keys(numeric),'data-page-break-before','data-page-break-after','data-keep-next','id'];
T.cleanHtml=function(input){
 const doc=new DOMParser().parseFromString('<body>'+String(input||'')+'</body>','text/html');
 const allowed=new Set([...blocks,'BR','STRONG','B','EM','I','U','S','UL','OL','A','IMG','SPAN']);
 function walk(parent){for(const el of [...parent.childNodes]){
  if(el.nodeType===3)continue;if(el.nodeType!==1){el.remove();continue;}
  if(['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','SVG','MATH','VIDEO','AUDIO','FORM'].includes(el.tagName)){el.remove();continue;}
  const align=el.getAttribute('data-align')||el.style?.textAlign;walk(el);
  if(!allowed.has(el.tagName)){el.replaceWith(...el.childNodes);continue;}
  const saved={};if(blocks.has(el.tagName)||el.tagName==='SPAN'){
   if(['left','center','right','justify'].includes(align))saved['data-align']=align;
   if(['serif','sans','mono'].includes(el.getAttribute('data-font-family')))saved['data-font-family']=el.getAttribute('data-font-family');
   for(const [k,[min,max]]of Object.entries(numeric)){const raw=el.getAttribute(k),v=T.num(raw);if(raw!==null&&v!==null&&v>=min&&v<=max)saved[k]=String(v);}
   const color=el.getAttribute('data-color');if(/^[a-f0-9]{6}$/i.test(color||''))saved['data-color']=color;
   for(const k of ['data-page-break-before','data-page-break-after','data-keep-next'])if(el.getAttribute(k)==='true')saved[k]='true';
   const anchor=el.getAttribute('id');if(/^doc-[A-Za-z0-9_.-]{1,90}$/.test(anchor||''))saved.id=anchor;
  }
  if(el.tagName==='A'){
   const href=el.getAttribute('href')||'';
   if(/^#doc-[A-Za-z0-9_.-]{1,90}$/.test(href))saved.href=href;
   else{try{const u=new URL(href);if(['https:','http:','mailto:'].includes(u.protocol))saved.href=u.href;}catch{}}
   saved.rel='noopener noreferrer';
  }
  if(el.tagName==='IMG'){
   const src=el.getAttribute('src')||'';
   if(!/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=\s]+$/i.test(src)){el.replaceWith(doc.createTextNode('[imagem não incorporada]'));continue;}
   saved.src=src;saved.alt=(el.getAttribute('alt')||'Imagem do livro').slice(0,500);
   const width=T.num(el.getAttribute('data-width-mm'));if(width>0&&width<=500)saved['data-width-mm']=String(width);
   saved['data-size']=['25','50','75','100'].includes(el.getAttribute('data-size'))?el.getAttribute('data-size'):'100';
   saved['data-align']=['left','center','right'].includes(el.getAttribute('data-align'))?el.getAttribute('data-align'):'center';
  }
  for(const a of [...el.attributes])el.removeAttribute(a.name);
  for(const [k,v]of Object.entries(saved))el.setAttribute(k,v);
  if(el.tagName==='IMG'&&saved['data-width-mm'])el.setAttribute('style','width:'+saved['data-width-mm']+'mm;max-width:100%;height:auto');
  if(blocks.has(el.tagName)||el.tagName==='SPAN'){
   const css=[];
   if(saved['data-align'])css.push('text-align:'+saved['data-align']);
   if(saved['data-font-family'])css.push('font-family:'+({'serif':'BookGaramond,serif','sans':'BookLato,sans-serif','mono':'monospace'}[saved['data-font-family']]));
   if(saved['data-text-size'])css.push('font-size:'+saved['data-text-size']+'pt');
   if(saved['data-color'])css.push('color:#'+saved['data-color']);
   if(saved['data-line-height'])css.push('line-height:'+saved['data-line-height']);
   for(const [k,prop,unit]of [['data-space-before','margin-top','pt'],['data-space-after','margin-bottom','pt'],['data-indent','text-indent','mm']])if(saved[k]!==undefined)css.push(prop+':'+saved[k]+unit);
   if(saved['data-page-break-before'])css.push('break-before:page');if(saved['data-page-break-after'])css.push('break-after:page');
   if(saved['data-keep-next'])css.push('break-after:avoid-page');
   if(css.length)el.setAttribute('style',css.join(';'));
  }
 }}walk(doc.body);return doc.body.innerHTML;
};
T.formatAttributes=attrNames;
})(window);
