<?php
/** Single-owner authentication/recovery. Included by api.php; never standalone. */
declare(strict_types=1);
if (!isset($store,$action)) { http_response_code(404); exit; }
function auth_save(string $path,array $value): void {
 $old=umask(0077);try {savej($path,$value);} finally {umask($old);}
}
function auth_stamp(array $a): string { return hash('sha256',(string)($a['password']??'').'|'.(string)($a['authVersion']??'')); }
function auth_session_valid(): bool {
 global $store;
 $a=loadj($store.'/account.json');
 return !empty($_SESSION['owner']) && isset($_SESSION['authStamp']) && $a && hash_equals(auth_stamp($a),(string)$_SESSION['authStamp']);
}
function auth_text(array $d,string $key,int $max=256): string {
 if(!is_string($d[$key]??null)||strlen($d[$key])>$max) fail('Dados inválidos.');
 return $d[$key];
}
function auth_password(array $d): string {
 $p=auth_text($d,'password',72);$confirm=auth_text($d,'confirm',72);
 if(strlen($p)<12 || str_contains($p,"\0") || !hash_equals($p,$confirm)) fail('Confirme uma senha com 12 a 72 bytes. Acentos podem ocupar mais de um byte.');
 return $p;
}
function auth_config(): array {
 global $store;
 $c=loadj($store.'/recovery-config.json');
 $url=(string)($c['baseUrl']??'');$u=parse_url($url);
 $ok=($c['enabled']??false)===true && is_array($u) && ($u['scheme']??'')==='https' && !empty($u['host']) && !isset($u['user']) && !isset($u['pass']) && !isset($u['query']) && !isset($u['fragment']) && !isset($u['port']) && in_array($u['path']??'',['','/'],true);
 $from=$c['from']??'';
 if(!$ok || !is_string($from) || !filter_var($from,FILTER_VALIDATE_EMAIL) || preg_match('/[\r\n]/',$from)) return [];
 return ['baseUrl'=>rtrim($url,'/'),'from'=>$from];
}
function auth_rate(string $scope,int $max,int $seconds): bool {
 global $store;
 $key=hash('sha256',$scope);$file=$store.'/rate/auth-'.$key.'.json';$r=loadj($file);$now=time();
 if(($r['until']??0)>$now) return false;
 $count=($now-(int)($r['first']??0)>$seconds)?1:(int)($r['count']??0)+1;
 $first=$count===1?$now:(int)$r['first'];
 savej($file,['first'=>$first,'count'=>$count,'until'=>$count>$max?$now+$seconds:0]);
 return $count<=$max;
}
function auth_mail(string $email,string $kind,string $token): bool {
 $c=auth_config();if(!$c) return false;
 $link=$c['baseUrl'].'/#recovery='.$kind.'.'.$token;
 $subject=$kind==='verify'?'Estudio do Livro - confirme seu email':'Estudio do Livro - redefina sua senha';
 $message="Foi solicitada uma operacao de seguranca para o Estudio do Livro.\n\nAbra este link em ate 30 minutos:\n".$link."\n\nSe nao foi voce, ignore esta mensagem. Nao compartilhe o link.\n";
 // Fixed, private configuration; never trust HTTP Host for recovery URLs.
 return @mail($email,$subject,$message,"From: ".$c['from']."\r\nContent-Type: text/plain; charset=UTF-8\r\n");
}
function auth_token(array $a,string $kind,string $email): array {
 $raw=bin2hex(random_bytes(32));
 $a['recovery'][$kind]=['hash'=>hash('sha256',$raw),'expires'=>time()+1800,'email'=>$email,'stamp'=>auth_stamp($a)];
 return [$a,$raw];
}
function auth_check_token(array $a,string $kind,string $raw): array {
 $r=$a['recovery'][$kind]??[];
 if(!preg_match('/^[a-f0-9]{64}$/D',$raw) || !is_array($r) || ($r['expires']??0)<=time() || !hash_equals((string)($r['hash']??''),hash('sha256',$raw)) || !hash_equals((string)($r['stamp']??''),auth_stamp($a))) fail('Link inválido, expirado ou já utilizado.',400);
 return $r;
}
function auth_set_password(array $a,string $p): array {
 $a['password']=password_hash($p,PASSWORD_DEFAULT);$a['authVersion']=bin2hex(random_bytes(16));$a['passwordChangedAt']=gmdate('c');unset($a['recovery']);return $a;
}
$authActions=['login','requestRecovery','resetPassword','beginEmail','verifyEmail','recoveryStatus','adminRecovery'];
if(in_array($action,$authActions,true)) {
 // One lock serializes account + rate + token transitions across sessions/workers.
 $authLock=fopen($store.'/.account-auth.lock','c');
 if(!$authLock || !flock($authLock,LOCK_EX)) fail('Não foi possível concluir a operação.',503);
 try {
  $account=loadj($store.'/account.json');
  if($action==='recoveryStatus') {logged();reply(['ok'=>true,'emailVerified'=>!empty($account['recoveryEmailVerifiedAt']),'email'=>$account['recoveryEmail']??null,'mailConfigured'=>(bool)auth_config()]);}
  $d=postdata();$ip=(string)($_SERVER['REMOTE_ADDR']??'unknown');
  if($action==='login') {
   if(!$account)fail('Conta ainda não configurada.',409);
   $p=auth_text($d,'password',200);
   // Preserve existing passwords; only newly chosen passwords have the bcrypt 72-byte bound.
   $rateFile=$store.'/rate/'.hash('sha256',$ip).'.json';$r=loadj($rateFile);$now=time();
   if(($r['until']??0)>$now) fail('Muitas tentativas. Aguarde 15 minutos após a última tentativa bloqueada.',429);
   if(str_contains($p,"\0") || !password_verify($p,(string)($account['password']??''))) {
    $count=($now-(int)($r['first']??$now)>900)?1:(int)($r['count']??0)+1;
    savej($rateFile,['first'=>$count===1?$now:(int)$r['first'],'count'=>$count,'until'=>$count>=8?$now+900:0]);fail('Senha incorreta.',401);
   }
   @unlink($rateFile);session_regenerate_id(true);$_SESSION['owner']=true;$_SESSION['authStamp']=auth_stamp($account);$_SESSION['csrf']=bin2hex(random_bytes(32));reply(['ok'=>true,'csrf'=>$_SESSION['csrf']]);
  }
  if($action==='requestRecovery') {
   $email=strtolower(trim(is_string($d['email']??null)?substr($d['email'],0,254):''));
   $generic=['ok'=>true,'message'=>'Se houver uma conta elegível, você receberá as instruções. Verifique também o spam.'];
   // All addresses get exactly the same status/body, including throttled requests.
   $allowed=auth_rate('request-ip:'.$ip,5,900);
   $allowed=auth_rate('request-global',10,3600)&&$allowed;
   if($allowed && auth_config() && !empty($account['recoveryEmailVerifiedAt']) && filter_var($email,FILTER_VALIDATE_EMAIL) && hash_equals((string)($account['recoveryEmail']??''),$email)) {
    [$next,$raw]=auth_token($account,'reset',$email);auth_save($store.'/account.json',$next);
    if(!auth_mail($email,'reset',$raw)){unset($next['recovery']['reset']);auth_save($store.'/account.json',$next);error_log('Estudio recovery: mail handoff failed');}
   }
   reply($generic);
  }
  if($action==='beginEmail') {
   logged();$p=auth_text($d,'password',200);
   if(!auth_rate('email-change:'.$ip,5,900))fail('Aguarde antes de tentar novamente.',429);
   if(str_contains($p,"\0")||!password_verify($p,(string)$account['password']))fail('Senha atual inválida.',403);
   $email=strtolower(trim(auth_text($d,'email',254)));
   if(!filter_var($email,FILTER_VALIDATE_EMAIL))fail('Informe um e-mail válido.');
   if(!auth_config())fail('Envio de e-mail ainda não configurado pelo administrador.',503);
   [$next,$raw]=auth_token($account,'verify',$email);auth_save($store.'/account.json',$next);
   if(!auth_mail($email,'verify',$raw)){unset($next['recovery']['verify']);auth_save($store.'/account.json',$next);fail('Não foi possível entregar a solicitação ao serviço de e-mail.',503);}
   reply(['ok'=>true,'message'=>'Confirme o endereço pelo link enviado.']);
  }
  if(!auth_rate('token-ip:'.$ip,12,900))fail('Aguarde antes de tentar novamente.',429);
  if($action==='verifyEmail') {
   $r=auth_check_token($account,'verify',auth_text($d,'token',64));
   $account['recoveryEmail']=$r['email'];$account['recoveryEmailVerifiedAt']=gmdate('c');unset($account['recovery']);auth_save($store.'/account.json',$account);reply(['ok'=>true,'message'=>'E-mail confirmado.']);
  }
  if($action==='resetPassword') {
   auth_check_token($account,'reset',auth_text($d,'token',64));$next=auth_set_password($account,auth_password($d));auth_save($store.'/account.json',$next);
   @unlink($store.'/rate/'.hash('sha256',$ip).'.json');$_SESSION=[];session_destroy();reply(['ok'=>true,'message'=>'Senha redefinida. Entre novamente.']);
  }
  if($action==='adminRecovery') {
   $path=$store.'/admin-recovery.key';$raw=auth_text($d,'key',64);
   clearstatcache(true,$path);$mtime=@filemtime($path);$expected=is_file($path)?trim((string)file_get_contents($path)):'';
   if(!$account || !$mtime || $mtime>time()+60 || $mtime<=time()-1800 || !preg_match('/^[a-f0-9]{64}$/D',$raw) || !preg_match('/^[a-f0-9]{64}$/D',$expected) || !hash_equals($expected,$raw) || hash_equals((string)($account['lastAdminKeyHash']??''),hash('sha256',$raw))) fail('Chave administrativa inválida, expirada ou já utilizada.',403);
   $next=auth_set_password($account,auth_password($d));$next['lastAdminKeyHash']=hash('sha256',$raw);auth_save($store.'/account.json',$next);
   @unlink($path);@unlink($store.'/rate/'.hash('sha256',$ip).'.json');$_SESSION=[];session_destroy();reply(['ok'=>true,'message'=>'Senha redefinida. Remova a chave administrativa pelo cPanel se ainda existir. Entre novamente.']);
  }
 } finally {flock($authLock,LOCK_UN);fclose($authLock);}
}
