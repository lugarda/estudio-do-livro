# Estúdio do Livro 1.1.1 — atualização manual pelo cPanel

**Roteiro para conferência. Nenhuma etapa foi executada na hospedagem.** Use somente
`estudio-do-livro-1.1.1-cpanel.zip` desta entrega. Os pacotes anteriores foram preparados
com outro backup e não são a indicação para esta instalação.

## Destinos confirmados pelo proprietário

- Aplicativo: `https://estudiodolivro.eduardogoncalvespsico.com/`
- Raiz pública: `/home2/edua3052/estudiodolivro.eduardogoncalvespsico.com`
- Dados privados: `/home2/edua3052/data`

O novo ZIP está organizado **diretamente para a raiz pública acima**. Dentro dele estão
`index.html`, `app.js` etc. e arquivos adicionais em `vendor/`. Não existe prefixo
`public/` nem uma pasta extra `estudio-do-livro/` a criar no subdomínio.

O pacote não contém `api.php`, pastas `data`/`books`/`profiles`/`publication`/`published`/
`rate`, `account.json`, chave de instalação, credenciais, livros ou executáveis de
instalação. Não altera PHP, sessões, conta, WordPress, banco de dados ou cron.

## 1. Antes da cópia

1. Salve o trabalho e feche todas as abas do Estúdio para evitar gravações concorrentes
   e mistura de arquivos antigos/novos durante a cópia. O WordPress principal pode
   continuar funcionando; não haverá tarefa ou mudança nele.
2. Preserve os dois backups que você já baixou, em local privado no computador. Não
   envie `books.zip` à raiz de nenhum site: esse backup inclui autenticação e livros.
3. Confirme no cPanel > Domínios que a raiz do subdomínio corresponde exatamente ao
   destino acima. No Gerenciador, confira que essa pasta contém `index.html`, `app.js`,
   `api.php`, `vendor/` e os arquivos descritos no manifesto.
4. Abra a configuração da API apenas em leitura, se necessário para conferir o local
   dos dados. No backup enviado, api.php usa `dirname(__DIR__).'/data'`; com a API na
   raiz do subdomínio informado, isso aponta para `/home2/edua3052/data`. Não editar
   esse caminho nem compartilhar o conteúdo de account.json ou configurações sensíveis.
5. Confira o ZIP pelo checksum externo e pelo manifesto. Não aplique se os arquivos
   atuais diferirem de forma relevante do backup enviado ou se houver alteração de
   terceiros posterior ao backup. Nesse caso, revisar a diferença antes de substituir.

## 2. Conferir em uma pasta separada

Pelo Gerenciador de Arquivos, envie o ZIP para uma pasta de conferência **fora de todos
os diretórios publicados e fora de data**. Escolha uma pasta nova, sem conteúdo de outro
sistema. Não é necessário usar Terminal, FTP, plugins ou criar um subdomínio novo.

Extraia ali e confira a estrutura: sete arquivos de substituição na raiz e os novos
módulos/fontes em suas posições. Não devem aparecer data, api.php, account.json ou
pastas do WordPress. A lista exata está em `ARQUIVOS-1.1.1.txt`.

## 3. Copiar após sua aprovação

No Gerenciador de Arquivos, copie os novos módulos JavaScript, a biblioteca fontkit,
as fontes e licenças para os mesmos caminhos relativos na raiz pública do Estúdio.
**Mescle os arquivos de vendor; não apague nem substitua vendor como uma pasta inteira.**
Os arquivos existentes JSZip, pdf-lib e PDF.js precisam continuar lá.

Substitua os seguintes arquivos por suas versões do pacote:

| Arquivo | Finalidade |
|---|---|
| `tools.js` | Modelo compatível, mantendo páginas/arquivos e importadores existentes |
| `app.js` | Importação segura, formatação, autosave e interface atual preservada |
| `export.js` | Fontes, Word, páginas manuais PDF/imagem e EPUB corrigidos |
| `reader.js` | Leitor de capítulos e páginas manuais preservado |
| `style.css` | Estilos/fontes e recursos visuais atuais preservados |
| `index.html` | Carregamento dos módulos atualizados |
| `ler.html` | Carregamento do leitor atualizado |

Copie os assets primeiro e os dois HTML por último. Se o cPanel solicitar sobrescrita,
confira nome e destino de cada arquivo. Nunca confirme sobrescrita da pasta privada.
Não substitua `api.php`, `.htaccess`, `.user.ini`, `php.ini`, dados, conta ou diretórios
inteiros. Não extraia o backup antigo ou uma versão de fonte completa no subdomínio.

Não modifique `/home2/edua3052/data`. **Não apagar, mover, recriar ou substituir essa
pasta**, suas subpastas, autenticação ou projetos. A atualização não exige esse procedimento.

## 4. Conferência após a atualização manual

1. Abra somente o subdomínio do Estúdio e faça atualização forçada do navegador. Se
   houver cache/CDN, revisar somente o cache desse subdomínio, sem purga global.
   `index.html` e `ler.html` devem referenciar os scripts/estilos com `?v=1.1.1`.
2. Entre com a mesma conta. Se aparecer **Criar acesso**, interrupção de dados ou lista
   vazia inesperada, pare: não crie conta, chave ou dados novos para contornar isso.
3. Confira os mesmos livros, títulos, capítulos, configurações e perfis, sem modificar
   os originais durante essa inspeção. A revisão anterior tinha dois projetos e o
   novo código foi testado com cópias deles, sem modificar os backups.
4. Se houver publicações já existentes, abra seus links em outra janela apenas para
   leitura. Confira capítulos e páginas manuais. Não republicar nem retirar livros
   reais do ar como teste; seus tokens e arquivos de publicação não foram alterados.
5. Crie um projeto fictício para ensaiar criar/editar/salvar/reabrir, aplicar formatação,
   reordenar capítulos e páginas, importar arquivos e exportar PDF/EPUB. Depois confira
   backup em JSON. Não use livros reais para testar exclusão ou conflitos.
6. A publicação/retirada foi testada apenas na API local. Se desejar repetir no servidor,
   faça isso somente com obra fictícia e autorização expressa para esse ensaio. O
   botão Publicar cria acesso por link; não é checkout ou entrega restrita a compradores.
7. Para recuperar a diagramação de um Word importado anteriormente sem estilos,
   **reimporte o DOCX original em um novo projeto**. A atualização preserva os dados
   antigos; não inventa estilos que já foram descartados antes. Não substitua o livro
   original. Fonte, entrelinha e paginação devem ser conferidas nas novas exportações.
8. Em arquivos para impressão, conferir corte, margens, fontes, resolução e medidas
   da capa no Previewer/calculador da KDP. Páginas PDF copiadas preservam medidas/fontes
   próprias; não recebem garantia de adequação automática. EPUB com PDF manual contém
   páginas rasterizadas, não texto editável nessas páginas.

## 5. Retorno à versão anterior, se necessário

Salve uma cópia JSON adicional de qualquer trabalho novo antes de retroceder. Reponha
somente os sete arquivos públicos substituídos usando o backup público fornecido.
Os assets novos podem permanecer sem uso se o HTML antigo não os referencia; não é
necessário apagar pastas. Versões antigas podem ignorar campos de formatação novos.

**Não restaure o backup privado por cima dos dados atuais como parte do rollback de
frontend.** Isso poderia substituir trabalho feito depois do backup. Uma restauração
operacional de data é um procedimento separado, que não está autorizado ou incluído.

## Quando suspender

Pare se o diretório não corresponder ao subdomínio, se surgir pedido de nova instalação,
se a conta/projetos não aparecerem, se houver erro de gravação ou se algum caminho
apontar ao WordPress ou outro subdomínio. Preserve evidências sem dados sensíveis.
Não altere permissões para 777 nem publique backups para resolver erros.
