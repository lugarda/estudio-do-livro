# Estúdio do Livro 1.1.1 — compatibilidade e preparação para cPanel

## Resultado

Pacote de frontend preparado especificamente a partir dos arquivos atuais enviados em
`vendor.zip`, para a raiz `/home2/edua3052/estudiodolivro.eduardogoncalvespsico.com`.
Nenhuma alteração foi realizada na hospedagem, no WordPress ou em outros subdomínios.
Não é plugin WordPress e não requer configuração de cron.

**Não aplicar o ZIP anterior 1.1.0 diretamente nesta instalação.** O backup atual inclui
páginas manuais, biblioteca de arquivos e importadores adicionais ausentes na primeira
base. As correções foram incorporadas mantendo esses recursos, resultando em 1.1.1.

## Backups recebidos

| Anexo | Verificação |
|---|---|
| books.zip | CRC íntegro; sete arquivos extraídos e comparados byte a byte em pasta local descartável |
| vendor.zip | CRC íntegro; 16 arquivos extraídos e comparados byte a byte em pasta local descartável |

A restauração física foi demonstrada localmente; isso não certifica permissões ou
restauração operacional na HostGator. O anexo privado contém dois projetos JSON e um
arquivo de autenticação. Os valores de autenticação não foram exibidos, distribuídos
ou usados para login. Ensaios de API usaram conta sintética e dados temporários.

As pastas de perfis/publicações do ZIP recebido não contêm arquivos para ensaiar seus
registros reais. Não se conclui que o servidor não tenha dados posteriores ao backup.
A validade de credenciais reais, tokens antigos, retenção e restauração da conta em
produção não foram testadas. Preserve os backups originais fora das raízes públicas.

## Correções incluídas

- Importação DOCX com herança de estilos, tamanho/fonte/cor, alinhamento, recuo,
  entrelinha, espaçamentos, quebras e dimensões físicas das imagens suportadas.
- Fonte 11,5 pt reconhecida. Aplicação explícita de fonte/tamanho no editor substitui
  a formatação dos runs internos que antes podia impedir a alteração desejada.
- Novo projeto por padrão ao importar Word, sem substituir o livro aberto. Capas
  identificadas são separadas do miolo, sem duplicar títulos/folha de rosto.
- Fontes locais incorporáveis no PDF; erros de glifo ausente são informados, sem
  descartar o texto. O processamento permanece local ao navegador e à API existente.
- Salvamento com falha não entra em loop de novas tentativas. Conteúdo aberto e cópia
  de segurança continuam disponíveis; controle de revisão não foi removido.
- EPUB mantém navegação; páginas manuais PDF/imagem continuam exportáveis. A regeneração
  do EPUB de páginas manuais foi corrigida para manter mimetype sem compressão, exigido
  pelo formato. Esse erro foi reproduzido no EPUBCheck e validado após a correção.
- Preparação KDP inclui alertas de formato/margens/resolução e ressalvas para PDFs
  copiados. Não certifica aceitação nem habilita vendas ou envios automáticos.

## Funcionalidades e dados preservados

A API PHP é **idêntica ao arquivo do backup atual**, incluindo publicação com chapters,
pages e pageAssets. O pacote não inclui nem substitui api.php. O caminho relativo de
armazenamento permanece o mesmo e corresponde ao data informado pelo proprietário.

Todos os 70 nomes de funções da aplicação e seus 33 handlers de ações atuais continuam
presentes, além das correções/adicionais. Isso é uma checagem de escopo; a evidência de
funcionamento é complementada pelos testes de navegador e API abaixo.

Mantidos criação, edição, diagramação, capítulos, páginas manuais, arquivo PDF/imagem,
importadores TXT/Word/RTF/ODT/EPUB, leitura publicada, publicação/retirada, perfis, backup
JSON e exportações. O visual escuro, as configurações de publicação e os demais assets
atuais foram preservados. O esquema JSON permanece 1; os campos opcionais de apresentação
não exigem migração. Nada regrava automaticamente os projetos para aplicar a atualização.

Os dois projetos enviados têm 24 e dois capítulos respectivamente; ambos possuem arrays
pages/pageAssets vazios no backup. O roundtrip preservou todos os campos salvos, incluindo
id, revisão, metadados, capítulos/HTML, cover, layout, print, pages e pageAssets. Os campos
novos titlePage/showTitle foram tratados como opcionais. A conta e o data real não foram
modificados. Páginas manuais foram ensaiadas separadamente com fixtures sintéticas.

A nova tipografia pode repaginar o PDF. Preservação de dados não significa paginação
idêntica à versão antiga ou ao Word. Formatação descartada numa importação anterior
precisa do DOCX original, reimportado em projeto novo, para ser recuperada.

## Testes executados nesta preparação

| Grupo | Resultado |
|---|---|
| Node | 26 casos aprovados, incluindo os dois projetos reais em cópias privadas, preservação de dados, geometria, PDF/EPUB e páginas manuais |
| Navegador — Word/edição | Dez cenários aprovados: importação do livro fornecido, edição, salvar/reabrir, segurança, backup em falha e layout desktop/celular |
| Navegador — compatibilidade atual | Seis cenários aprovados: PDF/EPUB de cada projeto, PDF/imagem manual, rasterização, RTF/ODT/EPUB e leitor publicado simulado |
| API PHP original | Quatro cenários locais com conta sintética: sessão/CSRF, dois ciclos leitura/save/conflito/publicação/retirada, perfis |
| EPUBCheck | Quatro EPUBs finais sem erros/avisos: Word, dois projetos existentes e páginas manuais |
| Sintaxe e escopo | JavaScript válido; API idêntica; funções/ações atuais mantidas |
| Pacote | CRC, caminhos seguros, arquivos previstos e hashes conferidos; sem PHP, data, autenticação ou livros |

O teste do Word manteve os 626 parágrafos na mesma ordem; o PDF de revisão tem 94 páginas
com fontes do texto incorporadas. Esses arquivos privados e os projetos fornecidos
não fazem parte da distribuição do aplicativo. Testes foram locais, não no subdomínio.
PHP do ensaio foi 8.4; não se altera a versão 8.3 da conta. Node/Java/Python são ferramentas
de desenvolvimento, sem instalação necessária na HostGator.

## Limites e aprovação

Compatibilidade demonstrada com os arquivos/projetos fornecidos e cenários descritos;
não é garantia de ausência de todo erro ou validação completa do servidor real. Faltam
aplicar manualmente e conferir cache, sessão, escrita, perfis e links reais no subdomínio.
Não houve teste de compra, provedor de pagamento, Amazon ou acesso a credenciais reais.

As capas originais ainda exigem revisão de resolução para impressão, definição de
papel/tinta e lombada/template. PDF importado mantém recursos próprios e EPUB rasterizado
não equivale a texto adaptável. Publicação por link não é venda com entrega protegida.

O pacote está pronto para sua conferência e homologação manual conforme o roteiro.
Não inclui instalador, migração, rotina de exclusão ou instrução de recriação do data.
O rollback previsto é somente dos arquivos públicos, preservando todos os dados privados.
